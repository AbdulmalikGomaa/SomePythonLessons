import zope.interface

from interface import Engine

@zope.interface.implementer(Engine)
class Rocket:
    def __init__(self):
        self.engine_state = 0

    def start_engine(self):
        if self.engine_state == 0:
            self.engine_state = 1
            print("Engine has strated.")
        else:
            print("Engine is already running.")

    def stop_engine(self):
        if self.engine_state == 1:
            self.engine_state = 0
            print("Engine has stopped.")
        else:
            print("Engine is already off.")


rock = Rocket()
rock.start_engine()
rock.start_engine()
rock.stop_engine()
rock.stop_engine()

