# lst1=["Mike", "Danny", "Jim", "Annie"]
# lst2=[4, 12, 7, 19]
#
# sorted_lst = list(zip(lst1,lst2))
# print(sorted_lst)

l1 = ['a', 'b', 'c', 'd', 'e', 'f']
l2 = [1, 2, 3, 4, 5]
l3 = dict(zip(l1, l2))
print(l3)
