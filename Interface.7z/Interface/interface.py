import zope.interface

class Engine(zope.interface.Interface):
    def start_engine(self):
        pass

    def stop_engine(self):
        pass